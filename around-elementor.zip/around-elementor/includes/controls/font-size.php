<?php
namespace AroundElementor\Includes\Controls;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

use Elementor\Base_Data_Control;

class Control_Font_Size extends Base_Data_Control {

    public function get_type() {
        return 'font_size';
    }

    public static function get_sizes() {
        
        $font_sizes = [
            'default'      => esc_html__( 'Default', 'around-elementor' ),
            'display-1'    => esc_html__( 'Display 1', 'around-elementor' ),
            'display-2'    => esc_html__( 'Display 2', 'around-elementor' ),
            'display-3'    => esc_html__( 'Display 3', 'around-elementor' ),
            'display-4'    => esc_html__( 'Display 4', 'around-elementor' ),
            'lead'         => esc_html__( 'Lead', 'around-elementor' ),
            'font-size-lg' => esc_html__( 'Font Size lg', 'around-elementor' ),
            'font-size-sm' => esc_html__( 'Font Size sm', 'around-elementor' ),
            'h1'           => esc_html__( 'h1', 'around-elementor' ),
            'h2'           => esc_html__( 'h2', 'around-elementor' ),
            'h3'           => esc_html__( 'h3', 'around-elementor' ),
            'h4'           => esc_html__( 'h4', 'around-elementor' ),
            'h5'           => esc_html__( 'h5', 'around-elementor' ),
            'h6'           => esc_html__( 'h6', 'around-elementor' ),
        ];

        $additional_sizes = apply_filters( 'around-elementor/controls/lk-font-size/font_size_options', [] );

        return array_merge( $font_sizes, $additional_sizes );
    }

    public function content_template() {
        $control_uid = $this->get_control_uid();
        ?>
        <div class="elementor-control-field">
            <label for="<?php echo $control_uid; ?>" class="elementor-control-title">{{{ data.label }}}</label>
            <div class="elementor-control-input-wrapper">
                <select id="<?php echo $control_uid; ?>" data-setting="{{ data.name }}">
                    <?php foreach ( static::get_sizes() as $key => $size ) : ?>
                    <option value="<?php echo $key; ?>"><?php echo $size; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <# if ( data.description ) { #>
        <div class="elementor-control-field-description">{{{ data.description }}}</div>
        <# } #>
        <?php
    }
}