<?php
namespace AroundElementor\Modules\Breadcrumb\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use AroundElementor\Base\Base_Widget;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Breadcrumb extends Base_Widget {

	public function get_name() {
		return 'ar-around-breadcrumb';
	}

	public function get_title() {
		return __( 'Around Breadcrumbs', 'around-elementor' );
	}

	public function get_icon() {
		return 'eicon-product-breadcrumbs';
	}

	public function get_keywords() {
		return [ 'shop', 'store', 'breadcrumbs', 'internal links', 'product' ];
	}

	protected function render() {
		around_breadcrumb();
	}

	public function render_plain_content() {}
}
	