<?php
namespace AroundElementor\Modules\MarketButton\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Core\Files\Assets\Files_Upload_Handler;
use AroundElementor\Base\Base_Widget;
use Elementor\Group_Control_Image_Size;
use AroundElementor\Core\Utils as AR_Utils;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;


/**
 * Around Elementor Market Button widget.
 *
 * Around Elementor widget that displays a Market Button with the ability to control every
 * aspect of the Market Button design.
 *
 * @since 1.0.0
 */
class Market_Button extends Base_Widget {

    private $files_upload_handler = false;

    /**
     * Get widget name.
     *
     * Retrieve Market Button widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'ar-market-button';
    }

    /**
     * Get widget title.
     *
     * Retrieve Market Button widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Market Button', 'around-elementor' );
    }

    /**
     * Get widget icon.
     *
     * Retrieve Market Button widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-image';
    }

    /**
     * Get widget keywords.
     *
     * Retrieve the list of keywords the widget belongs to.
     *
     * @since 2.1.0
     * @access public
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'market_button', 'image' ];
    }

    /**
     * Register icon list widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'section_market_btn',
            [
                'label' => __( 'Button', 'around-elementor' ),
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => __( 'Alignment', 'around-elementor' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __( 'Left', 'around-elementor' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'around-elementor' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __( 'End', 'around-elementor' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .around-market-button' => 'justify-content:{{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title1',
            [
                'label'       => esc_html__( 'Apple Button Title', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'App Store', 'around-elementor' ),
                'placeholder' => esc_html__( 'App Store', 'around-elementor' ),
            ]
        );

        $this->add_control(
            'subtitle1',
            [
                'label'       => esc_html__( 'Apple Button Sub Title', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Download on the', 'around-elementor' ),
                'placeholder' => esc_html__( 'Download on the', 'around-elementor' ),
            ]
        );

        $this->add_control(
            'link1',
            [
                'label' => __( 'Apple App Store Link', 'around-elementor' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __( 'https://your-link.com', 'around-elementor' ),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'title2',
            [
                'label'       => esc_html__( 'Google Button Title', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Google Play', 'around-elementor' ),
                'placeholder' => esc_html__( 'Google Play', 'around-elementor' ),
            ]
        );

        $this->add_control(
            'subtitle2',
            [
                'label'       => esc_html__( 'Google Button Sub Title', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Download on the', 'around-elementor' ),
                'placeholder' => esc_html__( 'Download on the', 'around-elementor' ),
            ]
        );

        $this->add_control(
            'link2',
            [
                'label' => __( 'Google App Store Link', 'around-elementor' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __( 'https://your-link.com', 'around-elementor' ),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'btn-outline', [
                'label'        => esc_html__( 'Butoon Outline?', 'around-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'around-elementor' ),
                'label_off'    => esc_html__( 'No', 'around-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_market_btn_style', [
                'label' => esc_html__( 'Market Button', 'around-elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label' => __( 'Title typography', 'around-elementor' ),
                'name' => 'Title typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_ACCENT,
                ],
                'selector' => '{{WRAPPER}} .btn-market-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label' => __( 'Subtitle typography', 'around-elementor' ),
                'name' => 'Subtitle typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_ACCENT,
                ],
                'selector' => '{{WRAPPER}} .btn-market-subtitle',
            ]
        );


        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Text Color', 'around-elementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .btn-market-title' => 'fill: {{VALUE}}; color: {{VALUE}};',
                    '{{WRAPPER}} .btn-market-subtitle' => 'fill: {{VALUE}}; color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'background_color',
            [
                'label' => __( 'Background Color', 'around-elementor' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-market' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => __( 'Border Radius', 'around-elementor' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .btn-market' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }


    protected function render() {
        $settings = $this->get_settings_for_display();

        if ( ! empty( $settings[ 'link1' ] ) ) {
            $this->add_link_attributes( 'button1', $settings[ 'link1' ] );
            $this->add_render_attribute( 'button1', 'class', [
                'btn-market btn-apple ',
                'yes' === $settings['btn-outline'] ? 'btn-outline ': '',
            ] );
            $this->add_render_attribute( 'button1', 'role', 'button' );
        }

        if ( ! empty( $settings[ 'link2' ] ) ) {
            $this->add_link_attributes( 'button2', $settings[ 'link2' ] );
            $this->add_render_attribute( 'button2', 'class', [ 
                'btn-market btn-google ',
                'yes' === $settings['btn-outline'] ? 'btn-outline ': '',
            ] );
            $this->add_render_attribute( 'button2', 'role', 'button' );
        }

        $this->add_render_attribute( 'subtitle1', 'class', 'btn-market-subtitle' );
        $this->add_render_attribute( 'title1', 'class', 'btn-market-title' );
        $this->add_render_attribute( 'subtitle2', 'class', 'btn-market-subtitle' );
        $this->add_render_attribute( 'title2', 'class', 'btn-market-title' );

        ?>
        <div class="around-market-button d-sm-flex">
            <div class="mr-sm-3 mb-3">
                <a <?php echo $this->get_render_attribute_string( 'button1' ); ?>>
                    <span <?php echo $this->get_render_attribute_string( 'subtitle1' ); ?>><?php echo $settings[ 'subtitle1' ]; ?></span>
                    <span <?php echo $this->get_render_attribute_string( 'title1' ); ?>><?php echo $settings[ 'title1' ]; ?></span>
                </a>
            </div>
            <div class="mb-3">
                <a <?php echo $this->get_render_attribute_string( 'button2' ); ?>>
                    <span <?php echo $this->get_render_attribute_string( 'subtitle2' ); ?>><?php echo $settings[ 'subtitle2' ]; ?></span>
                    <span <?php echo $this->get_render_attribute_string( 'title2' ); ?>><?php echo $settings[ 'title2' ]; ?></span>
                </a>
            </div>
        </div>
        <?php
    }
}