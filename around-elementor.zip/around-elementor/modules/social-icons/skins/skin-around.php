<?php
namespace AroundElementor\Modules\SocialIcons\Skins;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}


use Elementor;
use Elementor\Skin_Base;
use Elementor\Control_Media;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Controls_Manager;
use AroundElementor\Core\Utils as AR_Utils;
use Elementor\Icons_Manager;

class Skin_Around extends Skin_Base {

    public function __construct( Elementor\Widget_Base $parent ) {
        parent::__construct( $parent );
        add_filter( 'elementor/widget/print_template', [ $this, 'skin_print_template' ], 10, 2 );
        add_action( 'elementor/element/social-icons/section_social_icon/before_section_end', [ $this, 'section_skin_around_controls' ], 10 );
        //add_action( 'elementor/element/image-box/section_style_image/before_section_end', [ $this, 'style_image_controls' ] );
        //add_action( 'elementor/element/image-box/section_style_content/before_section_end', [ $this, 'style_content_controls' ] );
    }

    public function get_id() {
        return 'skin-around';
    }

    public function get_title() {
        return esc_html__( 'Around', 'around-elementor' );
    }

    public function skin_print_template( $content, $widget ) {
        if ( 'social-icons' == $widget->get_name() ) {
            return '';
        }
        return $content;
    }

    public function section_skin_around_controls( Elementor\Widget_Base $widget ) {

        $this->parent = $widget;

        $widget->update_control(
            'shape', [
                'condition' => [
                    '_skin' => '',
                ],
            ]
        );

        $this->add_control(
            'size', [
                'label' => __( 'Size', 'around-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'lg',
                'options' => [
                    'sm'     => __( 'Small', 'around-elementor' ),
                    '' => __( 'Medium', 'around-elementor' ),
                    'lg' => __( 'Large', 'around-elementor' ),
                ],
            ]
        );

        $this->add_control(
            'type', [
                'label' => __( 'Type', 'around-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    ''     => __( 'Solid', 'around-elementor' ),
                    'outline' => __( 'Outline', 'around-elementor' ),
                ],
            ]
        );


        $this->add_control(
            'shape', [
                'label' => __( 'Shape', 'around-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    ''     => __( 'Default', 'around-elementor' ),
                    'round' => __( 'Round', 'around-elementor' ),
                ],
            ]
        );

        $this->add_control(
            'enable_light', [
                'label'        => esc_html__( 'Enable Light Version', 'around-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'around-elementor' ),
                'label_off'    => esc_html__( 'No', 'around-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'description'  => esc_html__( 'On enable, it adds a lift effect on hover', 'around-elementor' )
            ]
        );

    }


    public function render() {
        $widget   = $this->parent;
        $settings = $widget->get_settings_for_display();
      
        $fallback_defaults = [
            'fa fa-facebook',
            'fa fa-twitter',
            'fa fa-google-plus',
        ];

        $class_animation = '';

        if ( ! empty( $settings['hover_animation'] ) ) {
            $class_animation = ' elementor-animation-' . $settings['hover_animation'];
        }

        $migration_allowed = Icons_Manager::is_migration_allowed();

        ?>
        <div class="around-social-icons elementor-social-icons-wrapper elementor-grid">
            <?php
            foreach ( $settings['social_icon_list'] as $index => $item ) {
                $migrated = isset( $item['__fa4_migrated']['social_icon'] );
                $is_new = empty( $item['social'] ) && $migration_allowed;
                $social = '';

                // add old default
                if ( empty( $item['social'] ) && ! $migration_allowed ) {
                    $item['social'] = isset( $fallback_defaults[ $index ] ) ? $fallback_defaults[ $index ] : 'fa fa-wordpress';
                }

                if ( ! empty( $item['social'] ) ) {
                    $social = str_replace(
                            array("fa fa-","fe fe-"),
                            array("", ""),
                            $item['social']
                    );
                } 


                if ( ( $is_new || $migrated ) && 'svg' !== $item['social_icon']['library'] ) {
                    $social = explode( ' ', $item['social_icon']['value'], 2 );
                    if ( empty( $social[1] ) ) {
                        $social = '';
                    } else {
                        $social = str_replace(
                            array("fa-","fe-"),
                            array("", ""),
                            $social[1]
                        );
                    }
                }

               

                if ( 'svg' === $item['social_icon']['library'] ) {
                    $social = get_post_meta( $item['social_icon']['value']['id'], '_wp_attachment_image_alt', true );
                }


                $link_key = 'link_' . $index;

                $social_buttons_size  = $settings[ $this->get_control_id( 'size' ) ];
                $social_buttons_type  = $settings[ $this->get_control_id( 'type' ) ];
                $social_buttons_shape = $settings[ $this->get_control_id( 'shape' ) ];
                $enable_light         = $settings[ $this->get_control_id( 'enable_light' ) ];

    
                $shape = isset( $settings['skin_around_shape'] ) && $social_buttons_shape === 'round' ? 'sb-round' : '';
                $type  = isset( $settings['skin_around_type'] )  && $social_buttons_type === 'outline' ? 'sb-outline' : '';
                $enable  = isset( $settings['skin_around_enable_light'] )  && $enable_light === 'yes' ? 'sb-light' : '';
                
                $widget->add_render_attribute( $link_key, 'class', [
                    'around-social-icon-' . $social . $class_animation,
                    'd-inline-block',
                    'elementor-repeater-item-' . $item['_id'],
                    $shape,
                    $type,
                    $enable,
                    'social-btn sb-' . $social_buttons_size .' sb-' . $social .' mr-1 mb-2'
                ] );

                $widget->add_link_attributes( $link_key, $item['link'] );

                ?>
                <a <?php echo $widget->get_render_attribute_string( $link_key ); ?>>
                    <span class="elementor-screen-only"><?php echo ucwords( $social ); ?></span>
                    <?php
                    if ( $is_new || $migrated ) {
                        Icons_Manager::render_icon( $item['social_icon'] );
                    } else { ?>
                        <i class="<?php echo esc_attr( $item['social'] ); ?>"></i>
                    <?php } ?>
                </a>
                
            <?php } ?>
        </div>
        <?php
    
    }

}