<?php
namespace AroundElementor\Modules\ImageGrid\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use AroundElementor\Base\Base_Widget;
use AroundElementor\Modules\ImageGrid\Skins;
use Elementor\Icons_Manager;
use Elementor\Plugin;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;
use Elementor\Utils;



class Image_Grid extends Base_Widget {

	public function get_name() {
        return 'ar-image-grid';
    }

    public function get_title() {
        return esc_html__( 'Image Grid', 'around-elementor' );
    }

    public function get_icon() {
        return 'eicon-gallery-justified';
    }

    protected $_has_template_content = false;

	protected function register_skins() {
		$this->add_skin( new Skins\Skin_Grid_1( $this ) );
		$this->add_skin( new Skins\Skin_Grid_2( $this ) );
    }

	protected function register_controls () {
		$this->start_controls_section( 'section_grid', [ 'label' => __( 'Grid Column 1 Settings', 'around-elementor' ) ] );

		$this->add_responsive_control(
            'column',
            [
                'type' => Controls_Manager::SELECT,
                'label' => __( 'Column 1', 'around-elementor' ),
                'options' => [
                    '' => __( 'Default', 'around-elementor' ),
                    '1' => __( '1', 'around-elementor' ),
                    '2' => __( '2', 'around-elementor' ),
                    '3' => __( '3', 'around-elementor' ),
                    '4' => __( '4', 'around-elementor' ),
                    '5' => __( '5', 'around-elementor' ),
                    '6' => __( '6', 'around-elementor' ),
                ],
                'frontend_available' => true,
                'condition' => [
                    '_skin' => 'grid-style-2'
                ]
            ]
        );

        $this->add_responsive_control(
            'column_2',
            [
                'type' => Controls_Manager::SELECT,
                'label' => __( 'Column 2', 'around-elementor' ),
                'options' => [
                    '' => __( 'Default', 'around-elementor' ),
                    '1' => __( '1', 'around-elementor' ),
                    '2' => __( '2', 'around-elementor' ),
                    '3' => __( '3', 'around-elementor' ),
                    '4' => __( '4', 'around-elementor' ),
                    '5' => __( '5', 'around-elementor' ),
                    '6' => __( '6', 'around-elementor' ),
                ],
                'frontend_available' => true,
                'condition' => [
                    '_skin' => 'grid-style-2'
                ]
            ]
        );

		$repeater = new Repeater();

        $repeater->add_control(
            'title', [
                'label'       => esc_html__( 'Title', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Title', 'around-elementor' ),
                'placeholder' => esc_html__( ' Title', 'around-elementor' ),
            ]
        );

        $repeater->add_control(
            'content', [
                'label'       => esc_html__( 'Content', 'around-elementor' ),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Find aute irure dolor in reprehend in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'around-elementor' ),
                'placeholder' => esc_html__( 'Image Grid Content', 'around-elementor' ),
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label' => __( 'Choose Image', 'around-elementor' ),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'content_settings', [
                'type'      => Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'title'    => esc_html__( 'SEO Website Audit', 'around-elementor' ),
                    ],
                    [
                        'title'    => esc_html__( 'Email Marketing', 'around-elementor' ),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $repeater_2 = new Repeater();

        $repeater_2->add_control(
            'title_2', [
                'label'       => esc_html__( 'Title', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'Title', 'around-elementor' ),
            ]
        );

        $repeater_2->add_control(
            'content_2', [
                'label'       => esc_html__( 'Content', 'around-elementor' ),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Find aute irure dolor in reprehend in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'around-elementor' ),
                'placeholder' => esc_html__( 'Image Grid Content', 'around-elementor' ),
            ]
        );

        $repeater_2->add_control(
            'image_2',
            [
                'label' => __( 'Choose Image', 'around-elementor' ),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'content_settings_2', [
                'type'      => Controls_Manager::REPEATER,
                'fields'    => $repeater_2->get_controls(),
                'default'   => [
                    [
                        'title_2'    => esc_html__( 'Content Marketing', 'around-elementor' ),
                    ],
                    [
                        'title_2'    => esc_html__( 'Link Building', 'around-elementor' ),
                    ],
                ],
                'title_field' => '{{{ title_2 }}}',
            ]
        );
		$this->end_controls_section();
	}
}

