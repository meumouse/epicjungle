<?php
namespace AroundElementor\Modules\CardsCarousel;

use AroundElementor\Base\Module_Base;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class Module extends Module_Base {

    public function get_widgets() {
        return [
            'Cards_Carousel',
        ];
    }

    public function get_name() {
        return 'ar-cards-carousel';
    }
}
