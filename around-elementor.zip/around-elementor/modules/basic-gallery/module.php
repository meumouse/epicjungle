<?php

namespace AroundElementor\Modules\BasicGallery;

use AroundElementor\Base\Module_Base;
use AroundElementor\Modules\BasicGallery\Skins;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class Module extends Module_Base {

    public function __construct() {
        parent::__construct();
        $this->add_actions();
    }

    public function get_name() {
        return 'ar-basic-gallery';
    }

    public function add_actions() {
        add_action( 'elementor/widget/image-gallery/skins_init', [ $this, 'init_skins' ], 10 );
        add_action( 'elementor/element/image-gallery/section_caption/before_section_end', [ $this, 'update_caption_control' ], 10 );
    }

    public function init_skins( $widget ) { 
        $widget->add_skin( new Skins\Skin_Light_Gallery( $widget ) );
        $widget->add_skin( new Skins\Skin_Around_Gallery( $widget ) );
    }

    public function update_caption_control( $element ) {

        $element->update_control(
            'gallery_display_caption',
            [
                'label' => __( 'Display', 'around-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __( 'Show', 'around-elementor' ),
                    'none' => __( 'Hide', 'around-elementor' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .cs_gallery-item .gallery-caption' => 'display: {{VALUE}};',
                ],
            ]
        );

      $element->add_control(
            'gallery_caption',
            [
                'label' => __( 'Display Text', 'around-elementor' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'description' => esc_html__( 'Text to be displayed on hover','around-elementor' )
                
                
            ]
        );
        $element->update_control(
            'align',
            [
                'label' => __( 'Alignment', 'around-elementor' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'around-elementor' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'around-elementor' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'around-elementor' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'around-elementor' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .cs_gallery-item .gallery-caption' => 'text-align: {{VALUE}};',
                ],
                'condition' => [
                    'gallery_display_caption' => '',
                ],
            ]
        );

        $element->update_control(
            'text_color',
            [
                'label' => __( 'Text Color', 'around-elementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .cs_gallery-item .gallery-caption' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'gallery_display_caption' => '',
                ],
            ]
        );

        // Remove the group control
    // $element->remove_control( 'typography_typography' );
    }

}