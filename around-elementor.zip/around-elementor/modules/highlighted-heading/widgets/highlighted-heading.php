<?php
namespace AroundElementor\Modules\HighlightedHeading\Widgets;

use AroundElementor\Base\Base_Widget;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use AroundElementor\Plugin;
use AroundElementor\Core\Controls_Manager AS LE_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Class Highlighted_Heading
 */
class Highlighted_Heading extends Base_Widget {

    public function get_name() {
        return 'highlighted-heading';
    }

    public function get_title() {
        return esc_html__( 'Highlighted Heading', 'around-elementor' );
    }

    public function get_icon() {
        return 'eicon-heading';
    }

    public function get_categories() {
        return [ 'around' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_title', [
                'label' => esc_html__( 'Title', 'around-elementor' ),
            ]
        );

        $this->add_control(
            'before_title', [
                'label'       => esc_html__( 'Before Highlighted Text', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'Enter your title', 'around-elementor' ),
                'default'     => 'Welcome to ',
                'description' => esc_html__( 'Use <br> to break into two lines', 'around-elementor' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'highlighted_text', [
                'label'       => esc_html__( 'Highlighted Text', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => '',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'after_title', [
                'label'       => esc_html__( 'After Highlighted Text', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => '',
                'placeholder' => esc_html__( 'Enter your title', 'around-elementor' ),
                'description' => esc_html__( 'Use <br> to break into two lines', 'around-elementor' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'link', [
                'label'     => esc_html__( 'Link', 'around-elementor' ),
                'type'      => Controls_Manager::URL,
                'dynamic'   => [
                    'active' => true,
                ],
                'default'   => [
                    'url' => '',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'size', [
                'label'   => esc_html__( 'Size', 'around-elementor' ),
                'type'    => LE_Controls_Manager::FONT_SIZE,
                'default' => '',
            ]
        );

        $this->add_control(
            'header_size', [
                'label'   => esc_html__( 'HTML Tag', 'around-elementor' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'h1'   => 'H1',
                    'h2'   => 'H2',
                    'h3'   => 'H3',
                    'h4'   => 'H4',
                    'h5'   => 'H5',
                    'h6'   => 'H6',
                    'div'  => 'div',
                    'span' => 'span',
                    'p'    => 'p',
                ],
                'default' => 'h2',
            ]
        );

        $this->add_responsive_control(
            'align', [
                'label' => esc_html__( 'Alignment', 'around-elementor' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'around-elementor' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'around-elementor' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'around-elementor' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__( 'Justified', 'around-elementor' ),
                        'icon'  => 'eicon-text-align-justify',
                    ],
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_highlighted_style', [
                'label' => esc_html__( 'Title', 'around-elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color', [
                'label'     => esc_html__( 'Title Color', 'around-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} .around-elementor-highlighted-heading__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .around-elementor-highlighted-heading__title',
                'global'   => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
            ]
        );

        $this->add_control(
            'title_css', [
                'label'       => esc_html__( 'Additional CSS', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'description' => esc_html__( 'Additional CSS classes separated by space that you\'d like to apply to the title', 'around-elementor' )
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_title_style', [
                'label' => esc_html__( 'Highlighted Text', 'around-elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'highlight_color', [
                'label'     => esc_html__( 'Highlight Color', 'around-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} .around-elementor-highlighted-heading__highlighted-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'     => 'highlighted_typography',
                'selector' => '{{WRAPPER}} .around-elementor-highlighted-heading__highlighted-text',
                'global'   => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
            ]
        );

        $this->add_control(
            'highlighted_css', [
                'label'       => esc_html__( 'Highlighted CSS', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'description' => esc_html__( 'Additional CSS classes separated by space that you\'d like to apply to the highlighted text', 'around-elementor' )
            ]
        );

        $this->end_controls_section();

         $this->start_controls_section(
            'section_parallax_style', [
                'label' => esc_html__( 'Parallax', 'around-elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'parallax_css', [
                'label'       => esc_html__( 'Prallax CSS', 'around-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'description' => esc_html__( 'Additional CSS classes separated by space that you\'d like to apply to the highlighted text', 'around-elementor' )
            ]
        );
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if ( '' === $settings['highlighted_text'] && '' === $settings['before_title'] ) {
            return;
        }

        $this->add_render_attribute( 'title', 'class', 'around-elementor-highlighted-heading__title' );

        if ( ! empty( $settings['size'] ) && 'default' !== $settings['size'] ) {
            $this->add_render_attribute( 'title', 'class', $settings['size'] );
        }

        if ( ! empty( $settings['title_css'] ) ) {
            $this->add_render_attribute( 'title', 'class', $settings['title_css'] );
        }

        $this->add_render_attribute( 'highlight', 'class', 'around-elementor-highlighted-heading__highlighted-text' );

        if ( ! empty( $settings['highlighted_css'] ) ) {
            $this->add_render_attribute( 'highlight', 'class', $settings['highlighted_css'] );            
        }

        if ( ! empty( $settings['highlighted_text'] ) ) {
            $highlighted_text = '<span ' . $this->get_render_attribute_string( 'highlight' ) . '>' . $settings['highlighted_text'] .'</span>';
        } else {
            $highlighted_text = '';
        }

        $title = $settings['before_title'] . $highlighted_text . $settings['after_title'];

        if ( ! empty( $settings['link']['url'] ) ) {
            $this->add_link_attributes( 'url', $settings['link'] );
            $this->add_render_attribute( 'url', 'class', [ 'text-reset', 'text-decoration-none' ] );

            $title = sprintf( '<a %1$s>%2$s</a>', $this->get_render_attribute_string( 'url' ), $title );
        }

        $title_html = sprintf( '<%1$s %2$s>%3$s</%1$s>', $settings['header_size'], $this->get_render_attribute_string( 'title' ), $title );

        echo $title_html;
    }

    protected function content_template() {
        ?>
        <#
        view.addRenderAttribute( 'highlight', 'class', 'around-elementor-highlighted-heading__highlighted-text');

        if ( '' !== settings.highlighted_css ) {
            view.addRenderAttribute( 'highlight', 'class', settings.highlighted_css );
        }

        var title = settings.before_title + '<span ' + view.getRenderAttributeString( 'highlight' ) + '>' + settings.highlighted_text + '</span>' + settings.after_title;

        if ( '' !== settings.link.url ) {
            title = '<a href="' + settings.link.url + '">' + title + '</a>';
        }

        view.addRenderAttribute( 'title', 'class', [ 'around-elementor-highlighted-heading__title', settings.size ] );

        if ( '' !== settings.title_css ) {
            view.addRenderAttribute( 'title', 'class', settings.title_css );
        }

        var title_html = '<' + settings.header_size  + ' ' + view.getRenderAttributeString( 'title' ) + '>' + title + '</' + settings.header_size + '>';

        print( title_html );
        #>
        <?php
    }
}