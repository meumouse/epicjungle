<?php
namespace AroundElementor\Modules\Woocommerce\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class Base_Widget extends \AroundElementor\Base\Base_Widget {

}
