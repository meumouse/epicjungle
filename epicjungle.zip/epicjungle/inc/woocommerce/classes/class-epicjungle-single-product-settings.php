<?php 

class EpicJungle_single_product_settings {

	public function __construct() {

		add_filter( 'woocommerce_get_sections_products', array( $this, 'add_section' ) );
		add_filter( 'woocommerce_get_settings_products', array( $this, 'ejsp_settings' ), 1, 2 );
	}

	public function add_section( $sections ) {
		$sections['ejsp'] = __( 'Página de produto único', 'epicjungle' );
		return $sections;
	}

	public function ejsp_settings( $settings, $current_section ) {

		if(  'ejsp' != $current_section )
			return $settings;

		$settings = array();
		
		$settings[] = array( 
			'name' => __( 'Página de produto único', 'epicjungle' ), 
			'type' => 'title', 
			'id'   => 'ejsp' 
		);

		$settings[] = array(
			'name'     => __( 'Exibir quantidade vendida do produto?', 'epicjungle' ),
			'desc_tip' => __( 'Desmarque para esconder o emblema de quantidade vendida na página do produto.', 'epicjungle' ),
			'id'       => 'ej_display_sale_badge',
			'type'     => 'checkbox',
			'default'  => 'yes',
			'css'      => 'min-width:300px',
			'desc'     => __( 'Mostrar quantidade vendida', 'epicjungle' ),
		);

		$settings[] = array(
			'name'     => __( 'Exibir botão comprar agora?', 'epicjungle' ),
			'desc_tip' => __( 'Desmarque para esconder o botão comprar agora na página do produto.', 'epicjungle' ),
			'id'       => 'ej_display_buy_now',
			'type'     => 'checkbox',
			'default'  => 'yes',
			'css'      => 'min-width:300px',
			'desc'     => __( 'Mostrar botão comprar agora', 'epicjungle' ),
		);

		$settings[] = array(
			'name'     => __( 'Exibir calculadora de frete?', 'epicjungle' ),
			'desc_tip' => __( 'Desmarque para esconder a calculadora de frete na página do produto.', 'epicjungle' ),
			'id'       => 'ejsp_show_calculator',
			'type'     => 'checkbox',
			'default'  => 'yes',
			'css'      => 'min-width:300px',
			'desc'     => __( 'Mostrar calculadora de frete', 'epicjungle' ),
		);

		return $settings;
	}
}

new EpicJungle_single_product_settings;