<?php
/**
 * The Template for displaying products in a doc tag. Simply includes the archive template
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

wedocs_get_template( 'archive-docs.php' );