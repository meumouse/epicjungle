<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package epicjungle
 */

do_action( 'epicjungle_after_canvas' );

wp_footer(); ?>

</body>

</html>