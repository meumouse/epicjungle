<?php
/**
 * The template used for displaying projects on index view
 *
 * @package epicjungle
 */
?>
<?php 
/**
* Functions hooked into epicjungle_loop_porfolio
*
*/
do_action( 'epicjungle_loop_portfolio' );