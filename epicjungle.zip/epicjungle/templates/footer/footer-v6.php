<?php
/**
 * Footer v6
 *
 */
?>
<footer id="colophon" class="site-footer cs-footer bg-dark pt-5 pb-4 footer-v6">
    <div class="container pb-2 text-center text-md-left"><?php
        
        /**
         * Functions hooked in to epicjungle_footer action
         *
         * @hooked epicjungle_footer_widgets  - 10
         */
        do_action( 'epicjungle_footer_v6' );
        
    ?></div><!-- .container -->
</footer><!-- #colophon --><?php 