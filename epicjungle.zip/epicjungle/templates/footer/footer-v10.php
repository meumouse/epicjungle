<?php
/**
 * Footer v10
 *
 */

?>
<footer class="cs-footer footer-dashboard py-4">
    <div class="container d-md-flex align-items-center justify-content-between py-2 text-center text-md-left">
    	<?php do_action( 'epicjungle_footer_simple' ); ?>
     </div>
</footer>