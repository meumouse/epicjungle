<?php
/**
 * Footer Default
 *
 */
?>
<footer id="colophon" class="cs-footer bg-dark footer-blog">
   <?php 
   /**
     * Functions hooked in to epicjungle_footer action
     *
     * @hooked epicjungle_footer_widgets  - 10
     */
    do_action( 'epicjungle_footer_blog' ); ?>
        
</footer><!-- #colophon --><?php 