/**
 * epicjungle.js
 *
 * Handles behaviour of the theme
 */
 ( function( $, window ) {
    'use strict';

    function maswcvsSelectedLabel() {
        $( '.mas-wcvs-swatches' ).each( function() {
            var $el = $( this ),
                $label = $el.closest( 'tr' ).find( '.label' );

            if( ! $el.find( '.selected' ).length && $label.find( '.mas-wcvs-swatch-selected' ).length ) {
                $label.find( '.mas-wcvs-swatch-selected' ).remove();
            }
        } );

        $( '.mas-wcvs-swatch.selected' ).each( function() {
            var $el = $( this ),
                $label = $el.closest( 'tr' ).find( '.label' );

            if ( $label.find( '.mas-wcvs-swatch-selected' ).length ) {
                $label.find( '.mas-wcvs-swatch-selected' ).html( $el.attr('title') );
            } else {
                $label.append( '<span class="mas-wcvs-swatch-selected ml-1">' + $el.attr('title') + '</span>' );
            }
        } );
    }

    maswcvsSelectedLabel();

    $( '.variations_form' ).on( 'woocommerce_variation_has_changed', function () {
        maswcvsSelectedLabel();
    } )
    .on( 'click', '.reset_variations', function () {
        maswcvsSelectedLabel();
    } );

    if( typeof $.blockUI !== "undefined" ) {
        $.blockUI.defaults.message                      = null;
        $.blockUI.defaults.overlayCSS.background        = '#fff url(' + epicjungle_options.ajax_loader_url + ') no-repeat center';
        $.blockUI.defaults.overlayCSS.backgroundSize    = '16px 16px';
        $.blockUI.defaults.overlayCSS.opacity           = 0.6;
    }

    $( 'body' ).on( 'adding_to_cart', function( e, $btn, data){
        $btn.closest( '.product' ).block();
    });

    $( 'body' ).on( 'added_to_cart', function(){
        $( '.product' ).unblock();
    });

    $(document).ready(function(){
        $(".apply_coupon").click(function(){
            $("form.checkout_coupon").hide();
        });
        
        $(".epicjungleshowcoupon").click(function(){
            $("form.checkout_coupon").show();
        });
    });

    /*===================================================================================*/
    /*  Deal Countdown timer
    /*===================================================================================*/

    $( '.deal-countdown-timer' ).each( function() {
        var deal_countdown_text = epicjungle_options.deal_countdown_text;
        // set the date we're counting down to
        var deal_time_diff = $(this).children('.deal-time-diff').text();
        var countdown_output = $(this).children('.deal-countdown');
        var target_date = ( new Date().getTime() ) + ( deal_time_diff * 1000 );

        // variables for time units
        var days, hours, minutes, seconds;

        // update the tag with id "countdown" every 1 second
        setInterval( function () {

            // find the amount of "seconds" between now and target
            var current_date = new Date().getTime();
            var seconds_left = (target_date - current_date) / 1000;

            // do some time calculations
            days = parseInt(seconds_left / 86400);
            seconds_left = seconds_left % 86400;

            hours = parseInt(seconds_left / 3600);
            seconds_left = seconds_left % 3600;

            minutes = parseInt(seconds_left / 60);
            seconds = parseInt(seconds_left % 60);

            // format countdown string + set tag value
            countdown_output.html( '<span data-value="' + days + '" class="days cs-countdown-days mr-grid-gutter"><span class="value cs-countdown-value">' + days +  '</span><span class="cs-countdown-label opacity-70 font-size-sm">' + deal_countdown_text.days_text + '</span></span><span class="hours cs-countdown-hours mr-grid-gutter"><span class="value cs-countdown-value">' + hours + '</span><span class="cs-countdown-label opacity-70 font-size-sm">' + deal_countdown_text.hours_text + '</span></span><span class="minutes cs-countdown-minutes mr-grid-gutter"><span class="value cs-countdown-value">'
            + minutes + '</span><span class="cs-countdown-label opacity-70 font-size-sm">' + deal_countdown_text.mins_text + '</span></span><span class="seconds cs-countdown-seconds"><span class="value cs-countdown-value">' + seconds + '</span><span class="cs-countdown-label opacity-70 font-size-sm">' + deal_countdown_text.secs_text + '</span></span>' );

        }, 1000 );
    });

    window.onload = function () {
        var preloader = document.querySelector('.cs-page-loading');
        if ( preloader !== null ) {
            preloader.classList.remove('active');
            setTimeout(function () {
                preloader.remove();
            }, 2000);
        }
    };


} )( jQuery, window );

// Auto atualizar carrinho após alterar quantidade
var timeout;
jQuery( function( $ ){
		$('.woocommerce').on('change', 'input.qty', function(){
	if ( timeout !== undefined ){
			clearTimeout( timeout );
}
	timeout = setTimeout(function(){
		$("[name='update_cart']").trigger("click");
	}, 300 );
	});
} );
//========

