/**
 * epicjungle.js
 *
 * Handles behaviour of the theme
 */
 ( function( $, window ) {
    'use strict';

    if( typeof $.blockUI !== "undefined" ) {
        $.blockUI.defaults.message                      = null;
        $.blockUI.defaults.overlayCSS.background        = '#fff url(' + epicjungle_options.ajax_loader_url + ') no-repeat center';
        $.blockUI.defaults.overlayCSS.backgroundSize    = '16px 16px';
        $.blockUI.defaults.overlayCSS.opacity           = 0.6;
    }

    $( 'body' ).on( 'adding_to_cart', function( e, $btn, data){
        $btn.closest( '.product' ).block();
    });

    $( 'body' ).on( 'added_to_cart', function(){
        $( '.product' ).unblock();
    });

    $(document).ready(function(){
        $(".apply_coupon").click(function(){
            $("form.checkout_coupon").hide();
        });
        
        $(".epicjungleshowcoupon").click(function(){
            $("form.checkout_coupon").show();
        });
    });

    /*===================================================================================*/
    /*  Deal Countdown timer
    /*===================================================================================*/

    $( '.deal-countdown-timer' ).each( function() {
        var deal_countdown_text = epicjungle_options.deal_countdown_text;
        // set the date we're counting down to
        var deal_time_diff = $(this).children('.deal-time-diff').text();
        var countdown_output = $(this).children('.deal-countdown');
        var target_date = ( new Date().getTime() ) + ( deal_time_diff * 1000 );

        // variables for time units
        var days, hours, minutes, seconds;

        // update the tag with id "countdown" every 1 second
        setInterval( function () {

            // find the amount of "seconds" between now and target
            var current_date = new Date().getTime();
            var seconds_left = (target_date - current_date) / 1000;

            // do some time calculations
            days = parseInt(seconds_left / 86400);
            seconds_left = seconds_left % 86400;

            hours = parseInt(seconds_left / 3600);
            seconds_left = seconds_left % 3600;

            minutes = parseInt(seconds_left / 60);
            seconds = parseInt(seconds_left % 60);

            // format countdown string + set tag value
            countdown_output.html( '<span data-value="' + days + '" class="days cs-countdown-days mr-grid-gutter"><span class="value cs-countdown-value">' + days +  '</span><span class="cs-countdown-label opacity-70 font-size-sm">' + deal_countdown_text.days_text + '</span></span><span class="hours cs-countdown-hours mr-grid-gutter"><span class="value cs-countdown-value">' + hours + '</span><span class="cs-countdown-label opacity-70 font-size-sm">' + deal_countdown_text.hours_text + '</span></span><span class="minutes cs-countdown-minutes mr-grid-gutter"><span class="value cs-countdown-value">'
            + minutes + '</span><span class="cs-countdown-label opacity-70 font-size-sm">' + deal_countdown_text.mins_text + '</span></span><span class="seconds cs-countdown-seconds"><span class="value cs-countdown-value">' + seconds + '</span><span class="cs-countdown-label opacity-70 font-size-sm">' + deal_countdown_text.secs_text + '</span></span>' );

        }, 1000 );
    });

    window.onload = function () {
        var preloader = document.querySelector('.cs-page-loading');
        if ( preloader !== null ) {
            preloader.classList.remove('active');
            setTimeout(function () {
                preloader.remove();
            }, 2000);
        }
    };


} )( jQuery, window );


/**
 * Auto update cart after change quantity
 * 
 * @since 1.0.0
 */
var timeout;
jQuery( function( $ ){
		$('.woocommerce').on('change', 'input.qty', function(){
	if ( timeout !== undefined ){
			clearTimeout( timeout );
}
	timeout = setTimeout(function(){
		$("[name='update_cart']").trigger("click");
	}, 300 );
	});
} );
//========

/**
 * Preloader button buy now single product
 * 
 * @since 1.3.0
 */
 jQuery(function($){
    $("#epicjungle_buy_now").click(function() {

        $("#preloader-buy-now-button").removeClass("d-none");
        $("#span-buy-now-button").addClass("d-none");
        $("#icon-buy-now-button").addClass("d-none");
    });
});


/**
 * Functions for avatar section
 * 
 * @since 1.3.0
 */
 jQuery(function($){

    /**
     * Preloader button send avatar
     */
    $("#inputSendAvatar").click(function() {

        $("#preloader-send-avatar").removeClass("d-none");
        $("#span-send-avatar").addClass("d-none");
    });

    /**
     * Disable send button if empty archive
     */
    $('#upload-file-avatar').change(function(e) {
        if($('#upload-file-avatar').val() == '') {
            $('#inputSendAvatar').attr('disabled', true );
        } 
        else {
          $('#inputSendAvatar').attr('disabled', false );
        }
    });
});


/**
 * Add to cart in AJAX
 * 
 * @since 1.3.0
 */
jQuery(function($){
    $('.single_add_to_cart_button').on('click', function(e){ 
    e.preventDefault();
    $thisbutton = $(this),
                $form = $thisbutton.closest('form.cart'),
                id = $thisbutton.val(),
                product_qty = $form.find('input[name=quantity]').val() || 1,
                product_id = $form.find('input[name=product_id]').val() || id,
                variation_id = $form.find('input[name=variation_id]').val() || 0;
    var data = {
            action: 'epicjungle_ajax_add_to_cart',
            product_id: product_id,
            product_sku: '',
            quantity: product_qty,
            variation_id: variation_id,
        };
    $.ajax({
            type: 'post',
            url: wc_add_to_cart_params.ajax_url,
            data: data,
            beforeSend: function (response) {
                $("#span-add-to-cart").addClass('d-none');
                $("#preloader-add-to-cart").removeClass('d-none');
                $('#epicjungle_buy_now').attr('disabled', true );
            },
            complete: function (response) {
                $("#epicjungle-add-to-cart").addClass('added').removeClass('d-none');
                $("#preloader-add-to-cart").addClass('d-none');
                $('#epicjungle_buy_now').attr('disabled', false );
            }, 
            success: function (response) { 
                $("#span-add-to-cart").removeClass('d-none');
                $('#epicjungle_buy_now').attr('disabled', false );

                if (response.error & response.product_url) {
                    window.location = response.product_url;
                    return;
                } else { 
                    $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $thisbutton]);
                } 
            }, 
        });
     });
});

/**
 * Input masks
 * 
 * @since 1.6.0
 */
jQuery(function($) {
	$("#wscp-calc_shipping_postcode_field").mask("99999-999");
    $("#wscp-postcode").mask("99999-999");
    $("#billing_postcode").mask("99999-999");
    $("#shipping_postcode").mask("99999-999");
    $("#billing_phone").mask("(99) 99999-9999");
});

/**
 * Auto complete data after enter postcode
 * 
 * @since 1.6.0
 */
 jQuery((function(n) {
    ({
        init: function() {
            var i = this;
            n(document.body).find("#billing_postcode").val() && !n(document.body).find("#billing_address_1").val() && this.autofill("billing"), n(document.body).find("#shipping_postcode").val() && !n(document.body).find("#shipping_address_1").val() && this.autofill("shipping"), n(document.body).find("#billing_postcode").on("keyup", (function(n) {
                return i.autofill("billing")
            })), n(document.body).find("#shipping_postcode").on("keyup", (function(n) {
                return i.autofill("shipping")
            }))
        },
        block: function() {
            n("form.checkout").block({
                message: null,
                overlayCSS: {
                    background: "#fff",
                    opacity: .6
                }
            })
        },
        unblock: function() {
            n("form.checkout").unblock()
        },
        autofill: function(i, o) {
            var l = this;
            o = o || !1;
            var t = n("#" + i + "_country").val();
            if (!n("#" + i + "_country").length || "BR" === t) {
                var e = n("#" + i + "_postcode"),
                    c = e.val().replace(/\D/g, "");
                c && 8 === c.length && (e.blur(), this.block(), n.ajax({
                    type: "GET",
                    url: "https://brasilapi.com.br/api/cep/v1/".concat(c),
                    dataType: "json",
                    contentType: "application/json",
                    success: function(n) {
                        if (n.state && (l.fillFields(i, n), o)) {
                            var t = "billing" === i ? "shipping" : "billing";
                            l.fillFields(t, n)
                        }
                    },
                    error: function(n) {
                        console.log(n)
                    },
                    complete: function() {
                        l.unblock()
                    }
                }))
            }
        },
        fillFields: function(i, o) {
            n("#" + i + "_address_1").val(o.street).change(), n("#" + i + "_neighborhood").length ? n("#" + i + "_neighborhood").val(o.neighborhood).change() : n("#" + i + "_address_2").val(o.neighborhood).change(), n("#" + i + "_city").val(o.city).change(), n("#" + i + "_state").val(o.state).trigger("change").change()
        }
    }).init()
}));

