<?php 

class WooSettings_Shipping_Calculator {

	public function __construct() {

		$this->id = 'wscip';
		$this->textdomain = 'wsc-plugin';

		add_filter( 'woocommerce_get_sections_products', array( $this, 'add_section' ) );
		add_filter( 'woocommerce_get_settings_products', array( $this, 'wscip_settings' ), 1, 2 );
		$this->update_default_customer_address();
	}

	public function update_default_customer_address() {

		$address  = get_option('woocommerce_default_customer_address');

		if( empty($address) )
			update_option( 'woocommerce_default_customer_address', 'geolocation' );
	}

	public function add_section( $sections ) {
		$sections['wscip'] = __( 'Calculadora de frete na página do produto', 'wsc-plugin' );
		return $sections;
	}

	public function wscip_settings( $settings, $current_section ) {

		if(  'wscip' != $current_section )
			return $settings;

		$settings = array();
		
		$settings[] = array( 
			'name' => __( 'Calculadora de frete na página do produto', 'wsc-plugin' ), 
			'type' => 'title', 
			'id'   => 'wscip' 
		);

		$settings[] = array(
			'name'     => __( 'Exibir calculadora?', 'wsc-plugin' ),
			'desc_tip' => __( 'Desmarque para esconder a calculadora na página de produto único.', 'wsc-plugin' ),
			'id'       => 'wscip_show_calculate',
			'type'     => 'checkbox',
			'default'  => 'yes',
			'css'      => 'min-width:300px',
			'desc'     => __( 'Mostrar calculadora', 'wsc-plugin' ),
		);

		return $settings;
	}
}

new WooSettings_Shipping_Calculator;