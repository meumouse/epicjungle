<?php

	class Woo_Shipping_Calculator {
		
		public function __construct() {
			add_action('wp', array($this,'init'));

			include_once EPICJUNGLE_EXTENSIONS_MODULES_DIR . '/shipping-calculator/class-ajax-postcode.php';
		}

		public function init() {

			if( is_product() && 'no' == get_option('ejsp_show_calculator','no') ){
			   echo '<style>#shipping-calc{display:none;}</style>'; }			
		}
	}
	new Woo_Shipping_Calculator;