<?php

	class Woo_Shipping_Calculator {
		
		public function __construct() {

			add_action('wp', array($this,'init'));
			add_action('plugins_loaded', function(){

				include_once dirname( __FILE__ ) . '/class-epicjungle-shipping-settings.php';					
			});

			include_once dirname( __FILE__ ) . '/class-ajax-postcode.php';
		}

		public function init() {

			if( is_product() && 'no' == get_option('wscip_show_calculate','no') ){
			   echo '<style>#shipping-calc{display:none;}</style>'; }			
		}
	}
	new Woo_Shipping_Calculator;