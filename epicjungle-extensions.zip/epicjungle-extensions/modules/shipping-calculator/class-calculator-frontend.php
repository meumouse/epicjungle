<?php 

class calculatorShippingFrontend {

	public function __construct() {
		add_action( 'wp_head', array( $this, 'set_var_admin_url_shipping_calc' ) );
		add_action( ( 'woocommerce_product_meta_end' ), array( $this, 'epicjungle_form_shipping_calc' ), 10);
	}

	public function epicjungle_form_shipping_calc() {
    $wscp_nonce = wp_create_nonce( 'wscp-nonce' );

    ?>
	<script src="/wp-content/themes/epicjungle/assets/js/jquery.mask.min.js"></script>
	<script src="/wp-content/plugins/epicjungle-extensions/assets/js/main.js"></script>

	<script type="text/javascript">
	jQuery(document).ready(function( $ ){
	    
    $("#wscp-postcode").mask("99999-999"); });
	</script>
	<?
		
		echo '<div id="shipping-calc">
		<label>Consultar prazo e valor da entrega</label>
		
		<div class="input-group form-group">
		  <input class="form-control" id="wscp-postcode" type="tel" placeholder="Informe seu CEP" name="wscp-postcode">
		  <button class="btn btn-primary" id="wscp-button" type="button">Calcular</button>
		</div>
		
		<a class="cs-fancy-link form-text postcode" href="https://buscacepinter.correios.com.br/app/endereco/" target="_blank">Não sei meu CEP</a>
		
		    <input type="hidden" name="wscp-nonce" id="wscp-nonce" value="'.$wscp_nonce.'"/>
			<input type="hidden" name="add-to-cart" value="<?= get_the_ID() ?>">
			<div id="wscp-response"></div>
		</div>';

	}

	public function set_var_admin_url_shipping_calc() {
		echo "<script> var wscp_admin_url = '".admin_url( 'admin-ajax.php' )."'; </script>";
		echo "<script> var wscp_assets_url = '".plugins_url( 'assets' )."'; </script>";
	}
}

new calculatorShippingFrontend();