<?php

class EJCC_Settings {

	public static function hooks() {
		add_action( 'customize_register', [ self::class, 'customizer' ] );

		if ( true === apply_filters( 'ejcc_tracker_settings_enabled', true ) ) {
			add_action( 'admin_init', [ self::class, 'integrity_settings' ] );
			add_action( 'admin_menu', [ self::class, 'integrity_settings_page' ] );
		}
	}

	/**
	 * Get the Policy URL from the settings.
	 *
	 * @return string
	 */
	public static function get_policy_url() {
		$wp_policy_url_page_id = get_option( 'wp_page_for_privacy_policy' );
		$default_url           = '#';
		if ( $wp_policy_url_page_id ) {
			$default_url = get_permalink( $wp_policy_url_page_id );
		}

		return apply_filters( 'ejcc_policy_url', get_option( 'ejcc_policy_url', $default_url ) );
	}

	/**
	 * Get the informational consent title.
	 *
	 * @return string
	 */
	public static function get_consent_title() {
		$title = get_option( 'ejcc_title', __( 'Este site usa cookies', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_consent_title', $title );
	}

	/**
	 * Get the informational consent text.
	 *
	 * @return string
	 */
	public static function get_consent_text() {

		$policy_url = self::get_policy_url();

		/* translators: 1. Policy URL */
		$default_text = sprintf( __( 'Usamos cookies para analisar nosso tráfego, personalizar o marketing e fornecer recursos de mídia social. <a class="cs-fancy-link" href="%s" rel="nofollow">Política de privacidade e cookies.</a>', 'epicjungle-extensions' ), $policy_url );

		$text = get_option( 'ejcc_text', $default_text );

		// check if we have linkstart and linkend, replace with link
		if ( strpos( $text, '%linkstart%' ) !== false && strpos( $text, '%linkend%' ) !== false ) {
			$text = str_replace( '%linkstart%', '<a href="' . $policy_url . '" rel="nofollow">', $text );
			$text = str_replace( '%linkend%', '</a>', $text );
		} // if we only have linkstart but no linked, add linkend
		elseif ( strpos( $text, '%linkstart%' ) !== false && strpos( $text, '%linkend%' ) === false ) {
			$text = str_replace( '%linkstart%', '<a href="' . $policy_url . '" rel="nofollow">', $text );
			$text = $text . '</a>';
		} // if we have linkend, but no linkstart, remove linkend
		elseif ( strpos( $text, '%linkstart%' ) === false && strpos( $text, '%linkend%' ) !== false ) {
			$text = str_replace( '%linkend%', '', $text );
		} // if we have a start a-tag but no end, add the end
		elseif ( strpos( $text, '<a' ) !== false && strpos( $text, '</a' ) === false ) {
			$text = $text . '</a>';
		} // if we only have an end a-tag, remove the endtag.
		elseif ( strpos( $text, '<a' ) === false && strpos( $text, '</a' ) !== false ) {
			$text = str_replace( '</a>', '', $text );
		}


		return apply_filters( 'ejcc_consent_text', $text, $policy_url );
	}

	/**
	 * Get the text for the accept button.
	 *
	 * @return string
	 */
	public static function get_accept_text() {
		$text = get_option( 'ejcc_button', __( 'Permitir todos os Cookies', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_accept_text', $text );
	}

	/**
	 * Get the text for the accept button.
	 *
	 * @return string
	 */
	public static function get_only_necessary_text() {
		$text = get_option( 'ejcc_only_necessary_text', __( 'Somente o necessário', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_only_necessary_text', $text );
	}

	/**
	 * Get the text for the settings configuration link.
	 *
	 * @return string
	 */
	public static function get_configure_settings_text() {
		$text = get_option( 'ejcc_configure_settings_text', __( 'Definir configurações', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_configure_settings_text', $text );
	}

	/**
	 * Get the style for the banner.
	 *
	 * @return string
	 */
	public static function get_style() {
		$style = get_option( 'ejcc_style', 'overlay' );

		return apply_filters( 'ejcc_style', $style );
	}

	/**
	 * Get the heading for the necessary cookies section.
	 *
	 * @return string
	 */
	public static function get_settings_necessary_heading() {
		$text = get_option( 'ejcc_settings_necessary_heading', __( 'Necessário', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_settings_necessary_heading', $text );
	}

	/**
	 * Get the description for the necessary cookies section.
	 *
	 * @return string
	 */
	public static function get_settings_necessary_description() {
		$text = get_option( 'ejcc_settings_necessary_description', __( 'Esses cookies não podem ser desativados. São requisitos para o site funcionar.', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_settings_necessary_description', $text );
	}

	/**
	 * Get the heading for the marketing cookies section.
	 *
	 * @return string
	 */
	public static function get_settings_marketing_heading() {
		$text = get_option( 'ejcc_settings_marketing_heading', __( 'Marketing', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_settings_marketing_heading', $text );
	}

	/**
	 * Get the description for the marketing cookies section.
	 *
	 * @return string
	 */
	public static function get_settings_marketing_description() {
		$text = get_option( 'ejcc_settings_marketing_description', __( 'Ao compartilhar seu comportamento de navegação em nosso site, podemos atendê-lo com conteúdo e ofertas personalizadas.', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_settings_marketing_description', $text );
	}

	/**
	 * Get the heading for the analytics cookies section.
	 *
	 * @return string
	 */
	public static function get_settings_analytics_heading() {
		$text = get_option( 'ejcc_settings_analytics_heading', __( 'Análise', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_settings_analytics_heading', $text );
	}

	/**
	 * Get the description for the analytics cookies section.
	 *
	 * @return string
	 */
	public static function get_settings_analytics_description() {
		$default = __( 'Para poder melhorar o site, incluindo informações e funcionalidades, queremos coletar análises. Não podemos identificá-lo pessoalmente usando esses dados.', 'epicjungle-extensions' );

		$text = get_option( 'ejcc_settings_analytics_description', $default );

		return apply_filters( 'ejcc_settings_analytics_description', $text );
	}

	/**
	 * Get the save settings button title.
	 *
	 * @return string
	 */
	public static function get_save_settings_button_title() {
		$text = get_option( 'ejcc_save_settings_text', __( 'Salvar configurações', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_save_settings_text', $text );
	}

	/**
	 * Get the settings title.
	 *
	 * @return string
	 */
	public static function get_settings_title() {
		$accept = get_option( 'ejcc_settings_title', __( 'Selecionar Cookies', 'epicjungle-extensions' ) );

		return apply_filters( 'ejcc_settings_title', $accept );
	}

	/**
	 * Get the save settings button title.
	 *
	 * @return string
	 */
	public static function get_settings_description() {
		$default = __( 'Cookies são pequenos arquivos de texto que o servidor web armazena em seu computador quando você visita o site.', 'epicjungle-extensions' );
		$text    = get_option( 'ejcc_settings_description', $default );

		return apply_filters( 'ejcc_settings_description', $text );
	}

	/**
	 * Check whether the analytics section should be shown or not.
	 *
	 * @return bool
	 */
	public static function is_analytics_shown() {
		$hidden = '' === get_option( 'ejcc_settings_analytics_is_shown', '1' );
		$shown  = ! $hidden;

		return apply_filters( 'ejcc_settings_analytics_is_shown', $shown );
	}

	/**
	 * Check whether the marketing section should be shown or not.
	 *
	 * @return bool
	 */
	public static function is_marketing_shown() {
		$hidden = '' === get_option( 'ejcc_settings_marketing_is_shown', '1' );
		$shown  = ! $hidden;

		return apply_filters( 'ejcc_settings_marketing_is_shown', $shown );
	}

	/**
	 * Add settings in the customer.
	 *
	 * @param WP_Customize_Manager $wp_customize
	 *
	 * @return void
	 */
	public static function customizer( $wp_customize ) {

		/**
		 * Set the filter to false to prevent the customizer
		 * settings from showing up.
		 */
		if ( ! apply_filters( 'ejcc_enable_customizer', true ) ) {
			return;
		}

		$wp_customize->add_panel( 'epicjungle_cookie_banner', [
			'priority'    => 120,
			'capability'  => apply_filters( 'ejcc_edit_style_capability', 'edit_theme_options' ),
			'title'       => __( 'Consentimento de Cookies', 'epicjungle-extensions' ),
			'description' => __( 'Personalize a aparência e os textos no banner de cookies, usado para conformidade com cookies da LGPD.', 'epicjungle-extensions' ),
		] );

		$wp_customize->add_section( 'epicjungle_cookie_banner_style', [
			'title' => __( 'Estilo', 'epicjungle-extensions' ),
			'panel' => 'epicjungle_cookie_banner',
		] );

		$wp_customize->add_section( 'epicjungle_cookie_banner_general', [
			'title' => __( 'Geral', 'epicjungle-extensions' ),
			'panel' => 'epicjungle_cookie_banner',
		] );

		$wp_customize->add_section( 'epicjungle_cookie_banner_necessary', [
			'title' => __( 'Seção: Necessário', 'epicjungle-extensions' ),
			'panel' => 'epicjungle_cookie_banner',
		] );

		$wp_customize->add_section( 'epicjungle_cookie_banner_analytics', [
			'title' => __( 'Seção: Análise', 'epicjungle-extensions' ),
			'panel' => 'epicjungle_cookie_banner',
		] );

		$wp_customize->add_section( 'epicjungle_cookie_banner_marketing', [
			'title' => __( 'Seção: Marketing', 'epicjungle-extensions' ),
			'panel' => 'epicjungle_cookie_banner',
		] );

		/**
		 * Style
		 */
		$wp_customize->add_setting( 'ejcc_style', [
			'default'    => 'overlay',
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_style_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_style', [
			'label'       => __( 'Estilo', 'epicjungle-extensions' ),
			'description' => __( 'O banner pode aparecer na parte superior, inferior ou sobreposto no meio da página.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_style',
			'section'     => 'epicjungle_cookie_banner_style',
			'priority'    => 80,
			'type'        => 'radio',
			'choices'     => [
			//	'top'      => __( 'Superior', 'epicjungle-extensions' ),
				'overlay'  => __( 'Inferior', 'epicjungle-extensions' ),
				'takeover' => __( 'Popup', 'epicjungle-extensions' ),
			],
		] ) );

		/**
		 * Title
		 */
		$wp_customize->add_setting( 'ejcc_title', [
			'default'    => __( 'Este site usa cookies para melhorar a experiência de navegação', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_title_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_title', [
			'label'       => __( 'Título', 'epicjungle-extensions' ),
			'description' => __( 'Mantenha o título curto. É estilizado com destaque.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_title',
			'section'     => 'epicjungle_cookie_banner_general',
			'priority'    => 80,
		] ) );

		/**
		 * Text with link
		 */
		$wp_customize->add_setting( 'ejcc_text', [
			'default'    => __( 'Ao continuar navegando no site, você concorda com nossa %linkstart% privacidade e política de cookies%linkend%.', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_text_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_text', [
			'label'       => __( 'Descrição', 'epicjungle-extensions' ),
			'description' => __( 'Uma linha secundária de informações sobre o uso de cookies. Lembre-se de vincular à política usando os espaços reservados %linkstart% e %linkend%.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_text',
			'section'     => 'epicjungle_cookie_banner_general',
			'priority'    => 80,
			'type'        => 'textarea',
		] ) );

		/**
		 * URL setting
		 */
		$wp_customize->add_setting( 'ejcc_policy_url', [
			'default'    => get_privacy_policy_url(),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_policy_url_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_policy_url', [
			'label'       => __( 'Link da página de política de privacidade', 'epicjungle-extensions' ),
			'description' => __( 'Insira um link para sua política de privacidade e cookies onde você descreve o uso de cookies. Se deixado em branco, a página de política de privacidade de Configurações > Privacidade será usada. Lembre-se de deixar esta página publicada.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_policy_url',
			'section'     => 'epicjungle_cookie_banner_general',
			'priority'    => 80,
		] ) );

		/**
		 * Button
		 */
		$wp_customize->add_setting( 'ejcc_button', [
			'default'    => __( 'Permitir todos os Cookies', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_button', [
			'label'       => __( 'Texto do botão Permitir todos os Cookies', 'epicjungle-extensions' ),
			'description' => __( 'Exibe a mensagem no botão de chamada para ação que adiciona consentimento para todos.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_button',
			'section'     => 'epicjungle_cookie_banner_general',
			'priority'    => 80,
		] ) );

		/**
		 * Only Necessary Button
		 */
		$wp_customize->add_setting( 'ejcc_only_necessary_text', [
			'default'    => __( 'Somente o necessário', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_only_necessary_text', [
			'label'       => __( 'Texto do botão Somente o necessário', 'epicjungle-extensions' ),
			'description' => __( 'Um botão secundário que exibe um call to action onde o usuário pode aceitar apenas os cookies necessários na página. Isso basicamente apenas fecha o banner.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_only_necessary_text',
			'section'     => 'epicjungle_cookie_banner_general',
			'priority'    => 80,
		] ) );

		/**
		 * Only Necessary Button
		 */
		$wp_customize->add_setting( 'ejcc_configure_settings_text', [
			'default'    => __( 'Definir configuraçoes', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_configure_settings_text', [
			'label'       => __( 'Texto do botão Definir configurações', 'epicjungle-extensions' ),
			'description' => __( 'Um pequeno botão/link no qual o usuário pode clicar para abrir configurações mais refinadas.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_configure_settings_text',
			'section'     => 'epicjungle_cookie_banner',
			'priority'    => 80,
		] ) );

		/**
		 * Settings Title
		 */
		$wp_customize->add_setting( 'ejcc_settings_title', [
			'default'    => __( 'Selecionar Cookies', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_title', [
			'label'       => __( 'Título das configurações', 'epicjungle-extensions' ),
			'description' => __( 'O título para a área de seleção de configurações.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_title',
			'section'     => 'epicjungle_cookie_banner_general',
			'priority'    => 80,
		] ) );

		/**
		 * Settings Description
		 */
		$wp_customize->add_setting( 'ejcc_settings_description', [
			'default'    => __( 'Cookies são pequenos arquivos de texto que o servidor web armazena em seu computador quando você visita o site.', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_description', [
			'label'       => __( 'Descrição das configurações', 'epicjungle-extensions' ),
			'description' => __( 'Uma descrição para que as pessoas saibam para que servem os cookies e por que elas podem selecionar opções diferentes.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_description',
			'section'     => 'epicjungle_cookie_banner_general',
			'priority'    => 80,
		] ) );

		/**
		 * Necessary Heading
		 */
		$wp_customize->add_setting( 'ejcc_settings_necessary_heading', [
			'default'    => __( 'Necessário', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_necessary_heading', [
			'label'       => __( 'Título Necessário', 'epicjungle-extensions' ),
			'description' => __( 'Um título para o grupo de cookies necessários.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_necessary_heading',
			'section'     => 'epicjungle_cookie_banner_necessary',
			'priority'    => 80,
		] ) );

		/**
		 * Necessary Text
		 */
		$wp_customize->add_setting( 'ejcc_settings_necessary_description', [
			'default'    => __( 'Esses cookies não podem ser desativados. São requisitos para o site funcionar.', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_necessary_description', [
			'label'       => __( 'Descrição Cookies necessários', 'epicjungle-extensions' ),
			'description' => __( 'Descreve para que são usados os cookies necessários.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_necessary_description',
			'section'     => 'epicjungle_cookie_banner_necessary',
			'priority'    => 80,
			'type'        => 'textarea',
		] ) );

		/**
		 * Show Analytics Section
		 */
		$wp_customize->add_setting( 'ejcc_settings_analytics_is_shown', [
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_analytics_is_shown', [
			'type'        => 'checkbox',
			'label'       => __( 'Mostrar seção de análise', 'epicjungle-extensions' ),
			'description' => __( 'Quando marcada, a seção de configuração de análise é mostrada. Se você não tiver rastreadores de análise, poderá desativar esta seção.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_analytics_is_shown',
			'section'     => 'epicjungle_cookie_banner_analytics',
			'priority'    => 80,
		] ) );

		/**
		 * Analytics Heading
		 */
		$wp_customize->add_setting( 'ejcc_settings_analytics_heading', [
			'default'    => __( 'Análise', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_analytics_heading', [
			'label'       => __( 'Título Análise', 'epicjungle-extensions' ),
			'description' => __( 'Um título para o grupo de cookies de análise.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_analytics_heading',
			'section'     => 'epicjungle_cookie_banner_analytics',
			'priority'    => 80,
		] ) );

		/**
		 * Analytics Text
		 */
		$wp_customize->add_setting( 'ejcc_settings_analytics_description', [
			'default'    => __( 'Para poder melhorar o site, incluindo informações e funcionalidades, queremos coletar análises. Não podemos identificá-lo pessoalmente usando esses dados.', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_analytics_description', [
			'label'       => __( 'Descrição da Análise', 'epicjungle-extensions' ),
			'description' => __( 'Descreve para que são usados os cookies de análise.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_analytics_description',
			'section'     => 'epicjungle_cookie_banner_analytics',
			'priority'    => 80,
			'type'        => 'textarea',
		] ) );

		/**
		 * Show Marketing Section
		 */
		$wp_customize->add_setting( 'ejcc_settings_marketing_is_shown', [
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_marketing_is_shown', [
			'type'        => 'checkbox',
			'label'       => __( 'Mostrar seção de marketing', 'epicjungle-extensions' ),
			'description' => __( 'Quando marcada, a seção de configuração de marketing é mostrada. Se você não tiver rastreadores de marketing, poderá desativar esta seção.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_marketing_is_shown',
			'section'     => 'epicjungle_cookie_banner_marketing',
			'priority'    => 80,
		] ) );

		/**
		 * Marketing Heading
		 */
		$wp_customize->add_setting( 'ejcc_settings_marketing_heading', [
			'default'    => __( 'Marketing', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_marketing_heading', [
			'label'       => __( 'Título de marketing', 'epicjungle-extensions' ),
			'description' => __( 'Um título para o grupo de cookies de marketing.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_marketing_heading',
			'section'     => 'epicjungle_cookie_banner_marketing',
			'priority'    => 80,
		] ) );

		/**
		 * Marketing Text
		 */
		$wp_customize->add_setting( 'ejcc_settings_marketing_description', [
			'default'    => __( 'Ao compartilhar seu comportamento de navegação em nosso site, podemos atendê-lo com conteúdo e ofertas personalizadas.', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_settings_marketing_description', [
			'label'       => __( 'Descrição de marketing', 'epicjungle-extensions' ),
			'description' => __( 'Descreve para que são usados os cookies de marketing.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_settings_marketing_description',
			'section'     => 'epicjungle_cookie_banner_marketing',
			'priority'    => 80,
			'type'        => 'textarea',
		] ) );

		/**
		 * Save Settings Button Text
		 */
		$wp_customize->add_setting( 'ejcc_save_settings_text', [
			'default'    => __( 'Salvar configurações', 'epicjungle-extensions' ),
			'type'       => 'option',
			'capability' => apply_filters( 'ejcc_edit_button_capability', 'edit_theme_options' ),
		] );

		$wp_customize->add_control( new \WP_Customize_Control( $wp_customize, 'ejcc_save_settings_text', [
			'label'       => __( 'Texto do botão Salvar configurações', 'epicjungle-extensions' ),
			'description' => __( 'O rótulo do botão que permite que os usuários salvem suas configurações.', 'epicjungle-extensions' ),
			'settings'    => 'ejcc_save_settings_text',
			'section'     => 'epicjungle_cookie_banner_general',
			'priority'    => 80,
		] ) );

	}

	public static function integrity_settings() {

		add_settings_section( 'ejcc_trackers_necessary', __( 'Necessário', 'epicjungle-extensions' ), function () {
			?>
			<p class="section-lead"><?php esc_html_e( 'Um usuário não pode optar por não permitir os cookies necessários. Estes devem ser cookies cruciais para a funcionalidade do site.', 'epicjungle-extensions' ); ?></p>
			<?php
		}, 'ejcc-trackers' );

		add_settings_field( 'ejcc_domains_necessary', __( 'Domínios', 'epicjungle-extensions' ), function () {
			?>
			<textarea name="ejcc_domains_necessary" id="ejcc_domains_necessary" style="width: 100%; max-width: 35rem;" rows="10"><?php echo esc_html( implode( "\n", EJCC_Trackers::get_necessary() ) ); ?></textarea>
			<p class="form-description"><?php esc_html_e( 'Digite um domínio por linha.', 'epicjungle-extensions' ); ?></p>
			<?php
		}, 'ejcc-trackers', 'ejcc_trackers_necessary' );

		add_settings_section( 'ejcc_trackers_analytics', __( 'Análise', 'epicjungle-extensions' ), function () {
			?>
			<p class="section-lead"><?php esc_html_e( 'Os cookies de marketing normalmente rastreiam o comportamento do usuário para fazer login em um sistema de CRM ou para veicular publicidade personalizada. É essencial para a conformidade com os regulamentos de privacidade separá-los e dar aos usuários uma escolha informada.', 'epicjungle-extensions' ); ?></p>
			<?php
		}, 'ejcc-trackers' );

		add_settings_field( 'ejcc_domains_analytics', __( 'Domínios', 'epicjungle-extensions' ), function () {
			?>
			<textarea name="ejcc_domains_analytics" id="ejcc_domains_analytics" style="width: 100%; max-width: 35rem;" rows="10"><?php echo esc_html( implode( "\n", EJCC_Trackers::get_analytics() ) ); ?></textarea>
			<p class="form-description"><?php esc_html_e( 'Digite um domínio por linha.', 'epicjungle-extensions' ); ?></p>
			<?php
		}, 'ejcc-trackers', 'ejcc_trackers_analytics' );

		add_settings_section( 'ejcc_trackers_marketing', __( 'Marketing', 'epicjungle-extensions' ), function () {
			?>
			<p class="section-lead"><?php esc_html_e( 'Os cookies de marketing normalmente rastreiam o comportamento do usuário para fazer login em um sistema de CRM ou para veicular publicidade personalizada. É essencial para a conformidade com os regulamentos de privacidade separá-los e dar aos usuários uma escolha informada.', 'epicjungle-extensions' ); ?></p>
			<?php
		}, 'ejcc-trackers' );

		add_settings_field( 'ejcc_domains_marketing', __( 'Domínios', 'epicjungle-extensions' ), function () {
			?>
			<textarea name="ejcc_domains_marketing" id="ejcc_domains_marketing" style="width: 100%; max-width: 35rem;" rows="10"><?php echo esc_html( implode( "\n", EJCC_Trackers::get_marketing() ) ); ?></textarea>
			<p class="form-description"><?php esc_html_e( 'Digite um domínio por linha.', 'epicjungle-extensions' ); ?></p>
			<?php
		}, 'ejcc-trackers', 'ejcc_trackers_marketing' );

		register_setting( 'ejcc-trackers', 'ejcc_domains_necessary' );
		register_setting( 'ejcc-trackers', 'ejcc_domains_analytics' );
		register_setting( 'ejcc-trackers', 'ejcc_domains_marketing' );
	}

	public static function integrity_settings_page() {
		add_options_page( __( 'Controle de rastreamento', 'epicjungle-extensions' ), __( 'Controle de rastreamento', 'epicjungle-extensions' ), 'manage_options', 'ejcc-trackers', function () {
			?>
			<div class="wrap">
				<h1><?php esc_html_e( 'Controle de rastreamento', 'epicjungle-extensions' ); ?></h1>
				<p class="lead"><?php esc_html_e( 'Para a conformidade com os regulamentos de privacidade, é importante dar ao usuário uma decisão informada a ser rastreada e perfilada. Fazemos isso dividindo qualquer domínio de configuração de cookies em três categorias.', 'epicjungle-extensions' ); ?></p>
				<p><?php esc_html_e( 'Adicionar domínios a essas listas de proibições garantirá que os scripts não carreguem e enviem dados antes que o usuário tenha consentido.', 'epicjungle-extensions' ); ?></p>
				<form action='options.php' method='post'>
					<?php
					settings_fields( 'ejcc-trackers' );
					do_settings_sections( 'ejcc-trackers' );
					submit_button();
					?>
				</form>
			</div>
			<style>
				p{
					max-width: 45rem; }
				p.lead{
					font-size: 1.1rem;
					opacity: 0.8;
					margin-top: 0; }
				h2{
					margin-bottom: 0.5em; }
				.section-lead{
					margin-top: 0; }
				p.form-description{
					font-style: italic;
					font-size: 85%; }
			</style>
			<?php
		} );
	}
}