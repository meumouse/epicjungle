<div class="wrap">
	<h2><?php echo $this->plugin->displayName; ?> &raquo; <?php esc_html_e( 'Configurações', 'epicjungle-extensions' ); ?></h2>

	<?php
	if ( isset( $this->message ) ) {
		?>
		<div class="updated fade"><p><?php echo $this->message; ?></p></div>
		<?php
	}
	if ( isset( $this->errorMessage ) ) {
		?>
		<div class="error fade"><p><?php echo $this->errorMessage; ?></p></div>
		<?php
	}
	?>

	<div id="poststuff">
		<div id="post-body-scripts" class="metabox-holder columns-2">
			<!-- Content -->
			<div id="post-body-content">
				<div id="normal-sortables" class="meta-box-sortables ui-sortable">
					<div class="postbox">
						<h3 class="hndle"><?php esc_html_e( 'Configurações', 'epicjungle-extensions' ); ?></h3>

						<div class="inside">
							<form action="options-general.php?page=<?php echo $this->plugin->name; ?>" method="post">
								<p>
									<label for="ej_scripts_insert_header"><strong><?php esc_html_e( 'Scripts no cabeçalho', 'epicjungle-extensions' ); ?></strong></label>
									<textarea name="ej_scripts_insert_header" id="ej_scripts_insert_header" class="widefat" rows="8" style="font-family:Courier New;" <?php echo ( ! current_user_can( 'unfiltered_html' ) ) ? ' disabled="disabled" ' : ''; ?>><?php echo $this->settings['ej_scripts_insert_header']; ?></textarea>
									<?php
									printf(
										/* translators: %s: The `<head>` tag */
										esc_html__( 'Estes scripts serão impressos na seção %s.', 'epicjungle-extensions' ),
										'<code>&lt;head&gt;</code>'
									);
									?>
								</p>
								<?php if ( $this->body_open_supported ) : ?>
								<p>
									<label for="ej_scripts_insert_body"><strong><?php esc_html_e( 'Scripts no corpo', 'epicjungle-extensions' ); ?></strong></label>
									<textarea name="ej_scripts_insert_body" id="ej_scripts_insert_body" class="widefat" rows="8" style="font-family:Courier New;" <?php echo ( ! current_user_can( 'unfiltered_html' ) ) ? ' disabled="disabled" ' : ''; ?>><?php echo $this->settings['ej_scripts_insert_body']; ?></textarea>
									<?php
									printf(
										/* translators: %s: The `<head>` tag */
										esc_html__( 'Esses scripts serão impressos logo abaixo da tag de abertura %s.', 'epicjungle-extensions' ),
										'<code>&lt;body&gt;</code>'
									);
									?>
								</p>
								<?php endif; ?>
								<p>
									<label for="ej_scripts_insert_footer"><strong><?php esc_html_e( 'Scripts no rodapé', 'epicjungle-extensions' ); ?></strong></label>
									<textarea name="ej_scripts_insert_footer" id="ej_scripts_insert_footer" class="widefat" rows="8" style="font-family:Courier New;" <?php echo ( ! current_user_can( 'unfiltered_html' ) ) ? ' disabled="disabled" ' : ''; ?>><?php echo $this->settings['ej_scripts_insert_footer']; ?></textarea>
									<?php
									printf(
										/* translators: %s: The `</body>` tag */
										esc_html__( 'Esses scripts serão impressos acima da tag de fechamento %s.', 'epicjungle-extensions' ),
										'<code>&lt;/body&gt;</code>'
									);
									?>
								</p>
								<?php if ( current_user_can( 'unfiltered_html' ) ) : ?>
									<?php wp_nonce_field( $this->plugin->name, $this->plugin->name . '_nonce' ); ?>
									<p>
										<input name="submit" type="submit" name="Submit" class="button button-primary" value="<?php esc_attr_e( 'Salvar', 'epicjungle-extensions' ); ?>" />
									</p>
								<?php endif; ?>
							</form>
						</div>
					</div>
					<!-- /postbox -->
				</div>
				<!-- /normal-sortables -->
			</div>
			<!-- /post-body-content -->

		</div>
	</div>
</div>
