<?php
/**
 * Coming Soon Metabox
 *
 * Displays the coming soon meta box, tabbed, with several panels covering price, stock etc.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * EpicJungle_Meta_Box_Coming_Soon Class.
 */
class EpicJungle_Meta_Box_Coming_Soon {

	/**
	 * Output the metabox.
	 *
	 * @param WP_Post $post
	 */

	public static function output( $post ) {

        global $post, $thepostid;

        wp_nonce_field( 'epicjungle_save_data', 'epicjungle_meta_nonce' );

        $thepostid      = $post->ID;

        $template_file  = get_post_meta( $thepostid, '_wp_page_template', true );

        if ( $template_file !== 'template-comingsoon.php' ) {
            return;
        }


        self::output_coming_soon( $post );
    }

    private static function output_coming_soon( $post ) {

    	if ( ! function_exists( 'epicjungle_get_coming_soon_meta' ) ) {
            return;
        }

        $ej_coming_soon_options = epicjungle_get_coming_soon_meta();

        $static_contents = function_exists( 'epicjungle_static_content_options' ) ? epicjungle_static_content_options() : [];

        $clean_meta_data = get_post_meta( $post->ID, '_ej_coming_soon_options', true );
        $ej_coming_soon_options = maybe_unserialize( $clean_meta_data );


        ?><div class="epicjungle-options">

                <?php

                epicjungle_wp_text_input( array(
	                'id'            => 'ej_coming_soon_options_title',
	                'name'          => 'ej_coming_soon_options[title]',
	                'label'         => esc_html__( 'Coming Soon Title', 'epicjungle-extensions' ),
	                'value'         => isset( $ej_coming_soon_options['title'] ) ? $ej_coming_soon_options['title'] : wp_kses_post( __( 'Coming Soon...', 'epicjungle-extensions' ) ),

	            ) ); 

                epicjungle_wp_textarea_input( array(
                    'id'            => 'ej_coming_soon_options_subtitle',
                    'name'          => 'ej_coming_soon_options[subtitle]',
                    'label'         => esc_html__( 'Coming Soon Subtitle', 'epicjungle-extensions' ),
                    'value'         => isset( $ej_coming_soon_options['subtitle'] ) ? $ej_coming_soon_options['subtitle'] : wp_kses_post( __( 'We are working hard to deliver best possible experience. The website is currently under construction. <u>It goes live in:</u>', 'epicjungle-extensions' ) ),
                ) );

                epicjungle_wp_text_input( array(
                    'id'            => 'ej_coming_soon_options_timer_value',
                    'label'         => esc_html__( 'Timer Value', 'epicjungle-extensions' ), 
                    'name'          => 'ej_coming_soon_options[timer_value]',
                    'value'         => isset( $ej_coming_soon_options['timer_value'] ) ? $ej_coming_soon_options['timer_value'] : '',
                ) );

                epicjungle_wp_text_input( array(
                    'id'            => 'ej_coming_soon_options_subscription_title',
                    'name'          => 'ej_coming_soon_options[subscription][title]',
                    'label'         => esc_html__( 'Subscription Title', 'epicjungle-extensions' ),
                    'value'         => isset( $ej_coming_soon_options['subscription']['title'] ) ? $ej_coming_soon_options['subscription']['title'] : wp_kses_post( __( 'Notify me!', 'epicjungle-extensions' ) ),

                ) ); 

                epicjungle_wp_textarea_input( array(
                    'id'            => 'ej_coming_soon_options_subscription_subtitle',
                    'name'          => 'ej_coming_soon_options[subscription][subtitle]',
                    'label'         => esc_html__( 'Subscription Subtitle', 'epicjungle-extensions' ),
                    'value'         => isset( $ej_coming_soon_options['subscription']['subtitle'] ) ? $ej_coming_soon_options['subscription']['subtitle'] : wp_kses_post( __( 'Let me know when your website is live and I can start order goods. Here is my email address:', 'epicjungle-extensions' ) ),
                ) );

                epicjungle_wp_text_input( array(
                    'id'            => 'ej_coming_soon_options_form_shortcode',
                    'name'          => 'ej_coming_soon_options[form][shortcode]',
                    'label'         => esc_html__( 'Subscription Form Shortcode', 'epicjungle-extensions' ),
                    'value'         => isset( $ej_coming_soon_options['form']['shortcode'] ) ? $ej_coming_soon_options['form']['shortcode'] : '',

                ) ); 



                if ( function_exists( 'epicjungle_is_mas_static_content_activated' ) && epicjungle_is_mas_static_content_activated() ) {

                    epicjungle_wp_select( array(
                        'id'            => 'ej_coming_soon_options_top_content',
                        'name'          => 'ej_coming_soon_options[top][content]',
                        'label'         => esc_html__( 'Header Static Content', 'epicjungle-extensions' ),
                        'options'       => $static_contents,
                        'value'         => isset( $ej_coming_soon_options['top']['content'] ) ? $ej_coming_soon_options['top']['content'] : '',

                    ) ); 

                    epicjungle_wp_select( array(
                        'id'            => 'ej_coming_soon_options_bottom_content',
                        'name'          => 'ej_coming_soon_options[bottom][content]',
                        'label'         => esc_html__( 'Footer Static Content', 'epicjungle-extensions' ),
                        'options'       => $static_contents,
                        'value'         => isset( $ej_coming_soon_options['bottom']['content'] ) ? $ej_coming_soon_options['bottom']['content'] : '',

                    ) );   
                }
            ?>

        </div><?php
        
    }

	public static function save( $post_id, $post ) {
        if ( isset( $_POST['ej_coming_soon_options'] ) ) {
            $clean_ej_coming_soon_options = epicjungle_clean_kses_post($_POST['ej_coming_soon_options'] );
            update_post_meta( $post_id, '_ej_coming_soon_options',  serialize( $clean_ej_coming_soon_options ) );
        }   
    }
}