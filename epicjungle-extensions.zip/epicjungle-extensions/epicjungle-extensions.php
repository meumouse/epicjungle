<?php
/**
 * Plugin Name:     EpicJungle Extensions
 * Plugin URI:      https://epicjungle.meumouse.com
 * Description:     Esta seleção de extensões complementa nosso tema EpicJungle. Atenção: eles não funcionam com nenhum tema WordPress, apenas EpicJungle.
 * Author:          MeuMouse.com
 * Author URI:      https://meumouse.com/
 * Version:         1.0.0
 * Text Domain:     epicjungle-extensions
 * Domain Path:     /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define EPICJUNGLE_PLUGIN_FILE.
if ( ! defined( 'EPICJUNGLE_PLUGIN_FILE' ) ) {
	define( 'EPICJUNGLE_PLUGIN_FILE', __FILE__ );
}

if ( ! class_exists( 'EpicJungle_Extensions' ) ) {
	/**
	 * Main EpicJungle_Extensions Class
	 *
	 * @class EpicJungle_Extensions
	 * @version 1.0.0
	 * @since 1.0.0
	 * @package EpicJungle
	 */
	final class EpicJungle_Extensions {

		/**
		 * EpicJungle_Extensions The single instance of EpicJungle_Extensions.
		 *
		 * @var     object
		 * @since   1.0.0
		 */
		private static $instance = null;

		/**
		 * The token.
		 *
		 * @var     string
		 * @since   1.0.0
		 */
		public $token;

		/**
		 * The version number.
		 *
		 * @var     string
		 * @since   1.0.0
		 */
		public $version;

		/**
		 * Constructor function.
		 *
		 * @since   1.0.0
		 * @return  void
		 */
		public function __construct() {

			$this->token   = 'epicjungle-extensions';
			$this->version = '1.0.0';

			add_action( 'plugins_loaded', array( $this, 'setup_constants' ), 10 );
			add_action( 'plugins_loaded', array( $this, 'includes' ), 20 );
		}

		/**
		 * Main EpicJungle_Extensions Instance
		 *
		 * Ensures only one instance of EpicJungle_Extensions is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see EpicJungle_Extensions()
		 * @return Main EpicJungle instance
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {

			// Plugin Folder Path.
			if ( ! defined( 'EPICJUNGLE_EXTENSIONS_DIR' ) ) {
				define( 'EPICJUNGLE_EXTENSIONS_DIR', plugin_dir_path( __FILE__ ) );
			}

			// Plugin Folder URL.
			if ( ! defined( 'EPICJUNGLE_EXTENSIONS_URL' ) ) {
				define( 'EPICJUNGLE_EXTENSIONS_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Root File.
			if ( ! defined( 'EPICJUNGLE_EXTENSIONS_FILE' ) ) {
				define( 'EPICJUNGLE_EXTENSIONS_FILE', __FILE__ );
			}

			// Modules File.
			if ( ! defined( 'EPICJUNGLE_EXTENSIONS_MODULES_DIR' ) ) {
				define( 'EPICJUNGLE_EXTENSIONS_MODULES_DIR', EPICJUNGLE_EXTENSIONS_DIR . '/modules' );
			}

			$this->define( 'EPICJUNGLE_ABSPATH', dirname( EPICJUNGLE_EXTENSIONS_FILE ) . '/' );
			$this->define( 'EPICJUNGLE_VERSION', $this->version );
		}

		/**
		 * Define constant if not already set.
		 *
		 * @param string      $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * What type of request is this?
		 *
		 * @param  string $type admin, ajax, cron or epicjungleend.
		 * @return bool
		 */
		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
				case 'epicjungleend':
					return ( ! is_admin() || defined( 'DOING_AJAX' ) ) && ! defined( 'DOING_CRON' ) && ! $this->is_rest_api_request();
			}
		}

		/**
		 * Include required files
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function includes() {
			/**
			 * Class autoloader.
			 */
			include_once EPICJUNGLE_EXTENSIONS_DIR . '/includes/class-epicjungle-autoloader.php';

			/**
			 * Core classes.
			 */
			require EPICJUNGLE_EXTENSIONS_DIR . '/includes/functions.php';

			/**
			 * Custom Post Types
			 */
			require EPICJUNGLE_EXTENSIONS_MODULES_DIR . '/portfolio/classes/class-epicjungle-jetpack-portfolio.php';

			if ( $this->is_request( 'admin' ) ) {
				include_once EPICJUNGLE_EXTENSIONS_DIR . '/includes/admin/class-epicjungle-extensions-admin.php';
			}

			/**
			 * Social Share
			 */
			require EPICJUNGLE_EXTENSIONS_MODULES_DIR . '/social-share/class-epicjungle-socialshare.php';
			
			/**
			 * Shipping Calculator
			 */
			require EPICJUNGLE_EXTENSIONS_MODULES_DIR . '/shipping-calculator/class-ajax-postcode.php';
			require EPICJUNGLE_EXTENSIONS_MODULES_DIR . '/shipping-calculator/class-calculator-frontend.php';
			require EPICJUNGLE_EXTENSIONS_MODULES_DIR . '/shipping-calculator/class-epicjungle-shipping-settings.php';
			require EPICJUNGLE_EXTENSIONS_MODULES_DIR . '/shipping-calculator/class-init-shipping-calculator.php';
		}

		/**
		 * Get the plugin url.
		 *
		 * @return string
		 */
		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', EPICJUNGLE_PLUGIN_FILE ) );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'epicjungle-extensions' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'epicjungle-extensions' ), '1.0.0' );
		}
	}
}

/**
 * Returns the main instance of EpicJungle_Extensions to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object EpicJungle_Extensions
 */
function EpicJungle_Extensions() { //phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return EpicJungle_Extensions::instance();
}

/**
 * Integration with MAS Static Content
 */

// Include the main Mas_Static_Content class.
if ( ! class_exists( 'Mas_Static_Content' ) ) {
    include_once dirname( EPICJUNGLE_PLUGIN_FILE ) . '/includes/class-mas-static-content.php';
}

/**
 * Unique access instance for Mas_Static_Content class
 */
function Mas_Static_Content() {
    return Mas_Static_Content::instance();
}

// Global for backwards compatibility.
$GLOBALS['mas_static_content'] = Mas_Static_Content();


/**
 * Integration with MAS WooCommerce Brands
 */

/**
 * Required functions
 */
if ( ! function_exists( 'mas_wcbr_is_woocommerce_active' ) ) {
	function mas_wcbr_is_woocommerce_active() {

		$active_plugins = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() ) {
			$active_plugins = array_merge( $active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );
		}

		return in_array( 'woocommerce/woocommerce.php', $active_plugins ) || array_key_exists( 'woocommerce/woocommerce.php', $active_plugins );
	}
}

if ( mas_wcbr_is_woocommerce_active() ) {
	// Include the main Mas_WC_Brands class.
	if ( ! class_exists( 'Mas_WC_Brands' ) ) {
		include_once dirname( EPICJUNGLE_PLUGIN_FILE ) . '/includes/class-mas-wc-brands.php';
	}

	/**
	 * Unique access instance for Mas_WC_Brands class
	 */
	function Mas_WC_Brands() {
		return Mas_WC_Brands::instance();
	}

	// Global for backwards compatibility.
	$GLOBALS['mas_wc_brands'] = Mas_WC_Brands();
}



/**
 * Initialise the plugin
 */
EpicJungle_Extensions();
