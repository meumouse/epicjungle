<?php
/**
 * Footer Default
 *
 */
?>
<footer id="colophon" class="cs-footer bg-dark footer-shop">
   <?php 
   /**
     * Functions hooked in to epicjungle_footer action
     *
     * @hooked epicjungle_footer_widgets  - 10
     */
    do_action( 'epicjungle_footer_shop' ); ?>
        
</footer><!-- #colophon --><?php 