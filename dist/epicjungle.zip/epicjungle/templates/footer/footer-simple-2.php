<?php
/**
 * Footer Simple 2
 *
 */
?>
<footer class="site-footer cs-footer bg-dark py-5 footer-simple-2">
    <div class="container d-sm-flex justify-content-between align-items-center text-center">
    	<?php do_action( 'epicjungle_footer_simple_2' ); ?>
     </div>
</footer>